#include <iostream>
using namespace std;

class Stack {
    int top;
    int capacity;
    float* arr;
public:
    Stack(int size) {
        top = -1;
        capacity = size;
        arr = new float[size];
    }
    void push(float x) {
        if (top == capacity - 1) {
            cout << "Stack Overflow" << endl;
            return;
        }
        arr[++top] = x;
    }
    float pop() {
        if (top == -1) {
            cout << "Stack Underflow" << endl;
            return -1;
        }
        return arr[top--];
    }
    float peek() {
        if (top == -1) {
            cout << "Stack is Empty" << endl;
            return -1;
        }
        return arr[top];
    }
    bool isEmpty() {
        return top == -1;
    }
    bool isFull() {
        return top == capacity - 1;
    }
};

int main() {
    Stack s(5);
    s.push(1.1);
    s.push(2.2);
    s.push(3.3);
    s.push(4.4);
    s.push(5.5);
    cout << "Elements present in stack : ";
    while (!s.isEmpty())
        cout << s.pop() << " ";
    cout << endl;
    return 0;
}
